create database myapp;
use myapp;
create table users (user varchar(60), pass varchar(60));
